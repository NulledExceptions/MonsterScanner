import UIKit

/// Thin wrapper over UIKit feedback generators. Main-thread only, like the generators themselves.
@MainActor
final class HapticsManager {
    private let light = UIImpactFeedbackGenerator(style: .light)
    private let heavy = UIImpactFeedbackGenerator(style: .heavy)
    private let notification = UINotificationFeedbackGenerator()

    func prepare() {
        light.prepare()
        heavy.prepare()
        Log.haptics.debug("Haptic generators prepared")
    }

    /// Light tap when a monster spawns.
    func spawn() {
        light.impactOccurred(intensity: 0.7)
        heavy.prepare()   // the reveal is coming next
        Log.haptics.debug("Spawn haptic")
    }

    /// Hard hit when a monster is revealed.
    func reveal() {
        heavy.impactOccurred(intensity: 1.0)
        notification.notificationOccurred(.error)
        light.prepare()
        Log.haptics.debug("Reveal haptic")
    }
}

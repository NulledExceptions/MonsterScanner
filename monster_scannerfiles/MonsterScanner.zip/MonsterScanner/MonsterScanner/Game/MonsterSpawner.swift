import Foundation

struct SpawnerConfiguration: Equatable {
    /// Delay before the very first monster, so the user gets a moment to look around.
    var initialDelay: ClosedRange<TimeInterval> = 5...9
    /// Time between the end of one cycle and the next spawn.
    var spawnInterval: ClosedRange<TimeInterval> = 12...18
    /// Random elevation offset applied to each monster.
    var pitchOffset: ClosedRange<Double> = -10...10
    /// Heading tolerance for a reveal.
    var revealTolerance: Double = 15
    /// Pitch tolerance for a reveal (deliberately generous — the pitch offset is a nudge, not a puzzle).
    var pitchTolerance: Double = 25
    var revealDuration: TimeInterval = 3
    var cooldownDuration: TimeInterval = 1.5
    /// Monsters never spawn closer than this to where the user is currently looking.
    var minimumSeparation: Double = 50

    static let `default` = SpawnerConfiguration()
}

enum SpawnerState: Equatable {
    case idle(nextSpawnAt: Date)
    case spawned(Monster)
    case revealed(Monster, since: Date)
    case cooldown(until: Date)

    var monster: Monster? {
        switch self {
        case .spawned(let monster), .revealed(let monster, _): monster
        case .idle, .cooldown: nil
        }
    }

    var name: String {
        switch self {
        case .idle: "idle"
        case .spawned: "spawned"
        case .revealed: "revealed"
        case .cooldown: "cooldown"
        }
    }
}

enum SpawnerEvent: Equatable {
    case spawned(Monster)
    case revealed(Monster)
    case hidden(Monster)
    case cooldownEnded(nextSpawnIn: TimeInterval)
}

/// Pure state machine: idle → spawned → revealed → cooldown → idle.
///
/// It has no timers of its own; the view model drives it by calling `update(now:orientation:)`
/// on a fixed tick, which keeps the logic deterministic and trivially testable.
struct MonsterSpawner {
    var configuration: SpawnerConfiguration
    private(set) var state: SpawnerState
    private(set) var revealedCount = 0
    private var rng = SystemRandomNumberGenerator()

    init(configuration: SpawnerConfiguration = .default, now: Date = Date()) {
        self.configuration = configuration
        let delay = TimeInterval.random(in: configuration.initialDelay)
        state = .idle(nextSpawnAt: now.addingTimeInterval(delay))
        Log.spawner.info("Spawner initialised; first spawn in \(delay, format: .fixed(precision: 1)) s")
    }

    // MARK: - Driving

    @discardableResult
    mutating func update(now: Date, orientation: Orientation?) -> [SpawnerEvent] {
        var events: [SpawnerEvent] = []

        switch state {
        case .idle(let nextSpawnAt):
            guard now >= nextSpawnAt else { break }
            let monster = makeMonster(now: now, awayFrom: orientation)
            state = .spawned(monster)
            events.append(.spawned(monster))
            Log.spawner.info("Spawned \(monster.art.rawValue, privacy: .public) at bearing \(monster.bearing, format: .fixed(precision: 1))°, pitch \(monster.pitch, format: .fixed(precision: 1))°")

        case .spawned(let monster):
            guard let orientation, Self.isAligned(orientation, with: monster, configuration: configuration) else { break }
            revealedCount += 1
            state = .revealed(monster, since: now)
            events.append(.revealed(monster))
            Log.spawner.info("Revealed monster #\(self.revealedCount) after \(now.timeIntervalSince(monster.spawnedAt), format: .fixed(precision: 1)) s")

        case .revealed(let monster, let since):
            guard now.timeIntervalSince(since) >= configuration.revealDuration else { break }
            state = .cooldown(until: now.addingTimeInterval(configuration.cooldownDuration))
            events.append(.hidden(monster))
            Log.spawner.debug("Monster hidden; cooling down")

        case .cooldown(let until):
            guard now >= until else { break }
            let delay = TimeInterval.random(in: configuration.spawnInterval, using: &rng)
            state = .idle(nextSpawnAt: now.addingTimeInterval(delay))
            events.append(.cooldownEnded(nextSpawnIn: delay))
            Log.spawner.debug("Cycle restarted; next spawn in \(delay, format: .fixed(precision: 1)) s")
        }

        return events
    }

    /// Returns to idle without touching the reveal counter (used when the app is backgrounded).
    mutating func reset(now: Date = Date()) {
        let delay = TimeInterval.random(in: configuration.initialDelay, using: &rng)
        state = .idle(nextSpawnAt: now.addingTimeInterval(delay))
        Log.spawner.info("Spawner reset; next spawn in \(delay, format: .fixed(precision: 1)) s")
    }

    // MARK: - Rules

    static func isAligned(_ orientation: Orientation, with monster: Monster, configuration: SpawnerConfiguration) -> Bool {
        let offset = Monster.offset(from: orientation, to: monster)
        return abs(offset.bearing) <= configuration.revealTolerance
            && abs(offset.pitch) <= configuration.pitchTolerance
    }

    private mutating func makeMonster(now: Date, awayFrom orientation: Orientation?) -> Monster {
        var bearing = Double.random(in: 0..<360, using: &rng)
        if let orientation, configuration.minimumSeparation > 0 {
            var attempts = 0
            while abs(Angles.signedDelta(from: orientation.heading, to: bearing)) < configuration.minimumSeparation, attempts < 12 {
                bearing = Double.random(in: 0..<360, using: &rng)
                attempts += 1
            }
        }
        let pitch = Double.random(in: configuration.pitchOffset, using: &rng)
        let art = MonsterArt.allCases.randomElement(using: &rng) ?? .lurker
        return Monster(bearing: bearing, pitch: pitch, art: art, spawnedAt: now)
    }
}

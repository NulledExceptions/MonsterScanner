import SwiftUI

/// Shared visual constants for the HUD so the night-vision look stays consistent.
enum Theme {
    /// Phosphor green used by every HUD element.
    static let phosphor = Color(red: 0.55, green: 1.0, blue: 0.62)
    static let hudFont = Font.system(.footnote, design: .monospaced, weight: .semibold)
    static let captionFont = Font.system(.caption2, design: .monospaced)
}

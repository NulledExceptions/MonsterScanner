import Foundation
import Observation
import SwiftUI

/// What the on-screen arrow should show.
struct ArrowGuidance: Equatable {
    /// Rotation in degrees: 0 = straight ahead (up), 90 = turn right, 180 = behind / look down, 270 = turn left.
    var rotation: Double
    var offset: AngularOffset
}

/// Single observable object that drives `ContentView`. Owns every component and the tick loop.
@MainActor
@Observable
final class ScannerViewModel {

    // MARK: - Observed state

    private(set) var orientation: Orientation?
    private(set) var spawnerState: SpawnerState
    private(set) var monsterCount = 0
    /// Non-nil while a monster is on screen. Changes are wrapped in `withAnimation` for the reveal/fade.
    private(set) var visibleMonster: Monster?
    private(set) var arrow: ArrowGuidance?
    private(set) var cameraMessage: String?
    private(set) var motionMessage: String?
    private(set) var isRunning = false

    var statusText: String {
        if cameraMessage != nil { return "CAMERA OFFLINE" }
        switch spawnerState {
        case .idle: return "SCANNING"
        case .spawned: return "SIGNAL DETECTED"
        case .revealed: return "CONTACT"
        case .cooldown: return "RECALIBRATING"
        }
    }

    var isScanning: Bool {
        if case .idle = spawnerState { return true }
        return false
    }

    /// Live access to the filter knobs; changes take effect on the next frame.
    var filterConfiguration: FilterConfiguration {
        get { pipeline.configuration }
        set { pipeline.configuration = newValue }
    }

    // MARK: - Components

    let frameStore = FrameStore()
    private let camera: CameraManager
    private let pipeline: FilterPipeline
    private let motion: MotionTracker
    private let audio: AudioManager
    private let haptics = HapticsManager()
    private let tickInterval: Duration = .milliseconds(50)

    @ObservationIgnored private var spawner: MonsterSpawner
    @ObservationIgnored private var tickTask: Task<Void, Never>?

    init(spawnerConfiguration: SpawnerConfiguration = .default,
         filterConfiguration: FilterConfiguration = .default,
         motionConfiguration: MotionConfiguration = .default) {
        camera = CameraManager()
        pipeline = FilterPipeline(configuration: filterConfiguration)
        motion = MotionTracker(configuration: motionConfiguration)
        audio = AudioManager()
        spawner = MonsterSpawner(configuration: spawnerConfiguration)
        spawnerState = spawner.state
        wireCallbacks()
    }

    // MARK: - Lifecycle

    /// Idempotent. Call on appear and whenever the scene becomes active.
    func start() async {
        guard !isRunning else { return }
        isRunning = true
        Log.viewModel.info("Starting scanner")

        haptics.prepare()

        do {
            try audio.prepare()
        } catch {
            Log.viewModel.error("Audio unavailable: \(error.localizedDescription, privacy: .public)")
        }

        motion.start()
        if case .unavailable(let reason) = motion.status {
            motionMessage = reason
        }

        startTicking()

        do {
            try await camera.start()
            cameraMessage = nil
        } catch {
            cameraMessage = error.localizedDescription
            Log.viewModel.error("Camera failed to start: \(error.localizedDescription, privacy: .public)")
        }
    }

    /// Call when the scene goes to the background. Keeps the monster counter.
    func stop() {
        guard isRunning else { return }
        isRunning = false
        tickTask?.cancel()
        tickTask = nil
        camera.stop()
        motion.stop()
        audio.stop()
        spawner.reset()
        spawnerState = spawner.state
        visibleMonster = nil
        arrow = nil
        Log.viewModel.info("Scanner stopped")
    }

    // MARK: - Wiring

    private func wireCallbacks() {
        // Hot path: runs on the camera's video queue. Only builds the lazy CIImage graph; no actor hops.
        let pipeline = pipeline
        let frameStore = frameStore
        camera.onFrame = { image in
            frameStore.set(pipeline.apply(to: image))
        }

        camera.onInterruption = { [weak self] message in
            Task { @MainActor in self?.cameraMessage = message }
        }

        motion.onUpdate = { [weak self] orientation in
            Task { @MainActor in self?.handle(orientation) }
        }
    }

    private func startTicking() {
        tickTask?.cancel()
        tickTask = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                guard let self else { return }
                self.tick()
                try? await Task.sleep(for: self.tickInterval)
            }
        }
    }

    // MARK: - Updates

    private func tick() {
        let events = spawner.update(now: Date(), orientation: orientation)
        if spawner.state != spawnerState {
            spawnerState = spawner.state
        }
        for event in events {
            handle(event)
        }
        updateGuidance()
    }

    private func handle(_ orientation: Orientation) {
        self.orientation = orientation
        updateGuidance()   // recompute at motion rate so the arrow tracks smoothly
    }

    private func handle(_ event: SpawnerEvent) {
        switch event {
        case .spawned(let monster):
            Log.viewModel.info("Monster spawned at \(monster.bearing, format: .fixed(precision: 0))°")
            audio.play(.spawn)
            haptics.spawn()

        case .revealed(let monster):
            monsterCount = spawner.revealedCount
            audio.play(.reveal)
            haptics.reveal()
            withAnimation(.spring(duration: 0.22, bounce: 0.35)) {
                visibleMonster = monster
            }

        case .hidden:
            withAnimation(.easeOut(duration: 0.8)) {
                visibleMonster = nil
            }

        case .cooldownEnded(let nextSpawnIn):
            Log.viewModel.debug("Cycle restarted; next spawn in \(nextSpawnIn, format: .fixed(precision: 1)) s")
        }
    }

    private func updateGuidance() {
        guard case .spawned(let monster) = spawnerState, let orientation else {
            if arrow != nil { arrow = nil }
            return
        }
        let offset = Monster.offset(from: orientation, to: monster)

        // Only let pitch steer the arrow when it is actually off; otherwise the arrow is purely left/right.
        let pitchComponent = abs(offset.pitch) <= spawner.configuration.pitchTolerance ? 0 : offset.pitch

        // Screen-space direction: x = turn left/right, y = look up/down. atan2(x, y) → 0 = up, 90 = right.
        let rotation = Angles.normalized(Angles.degrees(atan2(offset.bearing, pitchComponent)))
        arrow = ArrowGuidance(rotation: rotation, offset: offset)
    }
}

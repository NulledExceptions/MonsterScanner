import SwiftUI

/// Direction indicator shown while a monster is spawned but not yet in view.
struct ArrowView: View {
    let guidance: ArrowGuidance

    var body: some View {
        VStack(spacing: 18) {
            ZStack {
                Circle()
                    .strokeBorder(Theme.phosphor.opacity(0.22), lineWidth: 1)
                    .frame(width: 180, height: 180)
                Circle()
                    .strokeBorder(Theme.phosphor.opacity(0.12), lineWidth: 1)
                    .frame(width: 124, height: 124)

                Image(systemName: "arrowtriangle.up.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 44, height: 44)
                    .foregroundStyle(Theme.phosphor)
                    .shadow(color: Theme.phosphor.opacity(0.9), radius: 14)
                    .symbolEffect(.pulse)
                    .offset(y: -36)                       // sit on the ring…
                    .rotationEffect(.degrees(guidance.rotation))   // …and orbit around the centre
            }

            VStack(spacing: 4) {
                Text(directionLabel)
                    .tracking(3)
                Text(String(format: "%.0f°", guidance.offset.magnitude))
                    .foregroundStyle(Theme.phosphor.opacity(0.7))
                    .contentTransition(.numericText())
            }
            .font(Theme.hudFont)
            .foregroundStyle(Theme.phosphor)
        }
        .allowsHitTesting(false)
    }

    private var directionLabel: String {
        let offset = guidance.offset
        if abs(offset.bearing) >= abs(offset.pitch) {
            return offset.bearing > 0 ? "TURN RIGHT" : "TURN LEFT"
        } else {
            return offset.pitch > 0 ? "LOOK UP" : "LOOK DOWN"
        }
    }
}

#Preview {
    ZStack {
        Color.black
        ArrowView(guidance: ArrowGuidance(rotation: 70, offset: AngularOffset(bearing: 64, pitch: 12)))
    }
}

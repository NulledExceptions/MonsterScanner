import SwiftUI

struct ContentView: View {
    let viewModel: ScannerViewModel
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        ZStack {
            FilteredCameraView(frameStore: viewModel.frameStore)
                .ignoresSafeArea()

            if let monster = viewModel.visibleMonster {
                MonsterOverlayView(monster: monster)
                    .transition(.asymmetric(
                        insertion: .scale(scale: 0.25).combined(with: .opacity),
                        removal: .opacity
                    ))
                    .zIndex(2)
            }

            if let arrow = viewModel.arrow {
                ArrowView(guidance: arrow)
                    .transition(.opacity.combined(with: .scale(scale: 0.8)))
                    .zIndex(1)
            }

            HUDView(
                statusText: viewModel.statusText,
                isScanning: viewModel.isScanning,
                monsterCount: viewModel.monsterCount,
                heading: viewModel.orientation?.heading,
                message: viewModel.cameraMessage ?? viewModel.motionMessage
            )
            .zIndex(3)
        }
        .background(Color.black)
        .animation(.easeInOut(duration: 0.25), value: viewModel.arrow != nil)
        .task { await viewModel.start() }
        .onChange(of: scenePhase) { _, phase in
            switch phase {
            case .active:
                Task { await viewModel.start() }
            case .background:
                viewModel.stop()
            case .inactive:
                break   // transient (control centre, app switcher) — keep the camera warm
            @unknown default:
                break
            }
        }
    }
}

#Preview {
    ContentView(viewModel: ScannerViewModel())
}

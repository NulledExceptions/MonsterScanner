import SwiftUI

/// Minimal heads-up display: status line with scanning indicator, monster counter, and an
/// optional diagnostic/error message at the bottom.
struct HUDView: View {
    let statusText: String
    let isScanning: Bool
    let monsterCount: Int
    let heading: Double?
    let message: String?

    var body: some View {
        VStack {
            HStack(alignment: .firstTextBaseline) {
                HStack(spacing: 8) {
                    ScanIndicator(active: isScanning)
                    Text(statusText)
                        .tracking(2)
                }
                Spacer()
                HStack(spacing: 6) {
                    Image(systemName: "eye.fill")
                    Text("\(monsterCount)")
                        .contentTransition(.numericText())
                }
            }
            .font(Theme.hudFont)
            .foregroundStyle(Theme.phosphor)
            .padding(.horizontal, 20)
            .padding(.top, 8)
            .animation(.default, value: monsterCount)

            Spacer()

            if let message {
                Text(message)
                    .font(Theme.captionFont)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.red.opacity(0.9))
                    .padding(12)
                    .background(.black.opacity(0.6), in: RoundedRectangle(cornerRadius: 8))
                    .padding(.horizontal, 24)
                    .padding(.bottom, 6)
            }

            if let heading {
                Text(String(format: "HDG %03.0f°", heading))
                    .font(Theme.captionFont)
                    .foregroundStyle(Theme.phosphor.opacity(0.5))
                    .padding(.bottom, 10)
            }
        }
        .allowsHitTesting(false)
    }
}

private struct ScanIndicator: View {
    let active: Bool
    @State private var lit = false

    var body: some View {
        Circle()
            .fill(Theme.phosphor)
            .frame(width: 7, height: 7)
            .opacity(active ? (lit ? 1 : 0.15) : 1)
            .shadow(color: Theme.phosphor.opacity(lit ? 0.9 : 0), radius: 4)
            .onAppear {
                withAnimation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true)) {
                    lit = true
                }
            }
    }
}

#Preview {
    ZStack {
        Color.black
        HUDView(statusText: "SCANNING", isScanning: true, monsterCount: 3, heading: 212, message: nil)
    }
}
